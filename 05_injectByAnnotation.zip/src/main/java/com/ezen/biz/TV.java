package com.ezen.biz;

public interface TV {
	public void powerOn();
	public void powerOff();	
	public void volumUp();
	public void volumDown();
}
