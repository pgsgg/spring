package com.ezen.biz;

public interface Speaker {
	void volumeUp();
	
	void volumeDown();
}
